/* # Validando Formulario
============================================*/
$(document).ready(function(){
  $('#formulario').validate({
    errorElement: "span",
    rules: {
      txtNombre: {
        minlength: 2,
        maxlength: 30,
        required: true
      },
      txtPassword: {
        minlength: 2,
        required: true
      }
    },
    highlight: function(element) {
      $(element).closest('.control-group')
      .removeClass('success').addClass('error');
      validacion = false;
    },
    success: function(element) {
      element
      .html('<img src="img/ok.png" alt="ok" />Correcto!').addClass('help-inline')
      .closest('.control-group')
      .removeClass('error').addClass('success');
      validacion = true;
    }
  });
  $('#formulario').submit(function(evento){
    if (validacion) {
      $('#respuesta').hide(); 
      $('#respuesta').html('<span class="label label-success"> <i class="icon-refresh"></i> Procesando registro ... </span>').fadeIn('slow');
      evento.preventDefault();    
      var info = $(this).serialize();
      var sesion = info.substring(14);
      sessionStorage.hits = sesion;
      $.ajax({ 
        url: 'http://domicilios.net23.net/archivos/logueo.php', //la ruta entera
                 data: info,
                 type: 'POST',
                 dataType: 'json',
                 success: function(datos){
                   if (datos=='ok') {
                     $('#respuesta').html("<span class='label label-success'> <i class='icon-ok'></i> Registro correcto. </span>").fadeIn('slow');
                     window.location="registro_correcto.html";
                   }
          if (datos=='ko') {
                     $('#respuesta').html("<span class='label label-important'> <i class='icon-remove'></i> El email ya está registrado. </span>").fadeIn('slow');
                     //window.location="activacion.html";
                   }

                 }
                 });
    }            
  });
});
