<php?
function connectDB(){
 
   $conexion = mysqli_connect("SERVER", "USER", "PASS", "BASEDEDATOS");
    if($conexion){
        echo 'La conexión de la base de datos se ha hecho satisfactoriamente
';
    }else{
        echo 'Ha sucedido un error inesperado en la conexión de la base de datos
';
    }   
    return $conexion;
}
?>
