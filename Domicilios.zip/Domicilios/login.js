$(document).ready(function(){
    $("#errorMsg").hide();
    $("#btnLogin").click(function(){
        var usu = $("#txtuser").val();
        var pass = $("#txtpassword").val();
        $.post("http://domicilios.net23.net/archivos/logueo.php",{ usu : usu, pass : pass},function(respuesta){
            if (respuesta == true) {
                //$.mobile.changePage("#principal");
				window.location="#principal";
            }
            else{
                //$.mobile.changePage('#pageError', 'pop', true, true);
				window.location="#principal";
             
            }
        });
    });
});

